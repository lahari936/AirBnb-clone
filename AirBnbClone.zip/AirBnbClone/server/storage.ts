import { 
  type User, 
  type InsertUser, 
  type Property, 
  type InsertProperty,
  type Favorite,
  type InsertFavorite,
  type Booking,
  type InsertBooking,
  type Category,
  type InsertCategory,
  type PropertyCategory,
  type InsertPropertyCategory
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Property operations
  getAllProperties(): Promise<Property[]>;
  getProperty(id: number): Promise<Property | undefined>;
  getPropertiesByCategory(categoryId: number): Promise<Property[]>;
  searchProperties(query: string): Promise<Property[]>;
  createProperty(property: InsertProperty): Promise<Property>;
  
  // Favorite operations
  getFavoritesByUser(userId: number): Promise<Property[]>;
  isFavorite(userId: number, propertyId: number): Promise<boolean>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: number, propertyId: number): Promise<boolean>;
  
  // Booking operations
  createBooking(booking: InsertBooking): Promise<Booking>;
  getUserBookings(userId: number): Promise<Booking[]>;
  
  // Category operations
  getAllCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // PropertyCategory operations
  getPropertyCategories(propertyId: number): Promise<Category[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private properties: Map<number, Property>;
  private favorites: Map<number, Favorite>;
  private bookings: Map<number, Booking>;
  private categories: Map<number, Category>;
  private propertyCategories: Map<number, PropertyCategory>;
  
  private userNextId: number = 1;
  private propertyNextId: number = 1;
  private favoriteNextId: number = 1;
  private bookingNextId: number = 1;
  private categoryNextId: number = 1;
  private propertyCategoryNextId: number = 1;

  constructor() {
    this.users = new Map();
    this.properties = new Map();
    this.favorites = new Map();
    this.bookings = new Map();
    this.categories = new Map();
    this.propertyCategories = new Map();
    
    // Initialize with mock data
    this.initializeData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userNextId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Property operations
  async getAllProperties(): Promise<Property[]> {
    return Array.from(this.properties.values());
  }

  async getProperty(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }
  
  async getPropertiesByCategory(categoryId: number): Promise<Property[]> {
    const propertyCategoryEntries = Array.from(this.propertyCategories.values())
      .filter(pc => pc.categoryId === categoryId);
      
    return propertyCategoryEntries.map(pc => 
      this.properties.get(pc.propertyId)
    ).filter(Boolean) as Property[];
  }
  
  async searchProperties(query: string): Promise<Property[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.properties.values()).filter(property => 
      property.title.toLowerCase().includes(lowercaseQuery) ||
      property.description.toLowerCase().includes(lowercaseQuery) ||
      property.location.toLowerCase().includes(lowercaseQuery) ||
      property.city.toLowerCase().includes(lowercaseQuery) ||
      property.state.toLowerCase().includes(lowercaseQuery) ||
      property.country.toLowerCase().includes(lowercaseQuery)
    );
  }
  
  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const id = this.propertyNextId++;
    const property: Property = { ...insertProperty, id };
    this.properties.set(id, property);
    return property;
  }

  // Favorite operations
  async getFavoritesByUser(userId: number): Promise<Property[]> {
    const userFavorites = Array.from(this.favorites.values())
      .filter(favorite => favorite.userId === userId);
      
    return userFavorites.map(favorite => 
      this.properties.get(favorite.propertyId)
    ).filter(Boolean) as Property[];
  }
  
  async isFavorite(userId: number, propertyId: number): Promise<boolean> {
    return Array.from(this.favorites.values()).some(
      favorite => favorite.userId === userId && favorite.propertyId === propertyId
    );
  }
  
  async addFavorite(insertFavorite: InsertFavorite): Promise<Favorite> {
    // Check if already a favorite
    const existing = Array.from(this.favorites.values()).find(
      fav => fav.userId === insertFavorite.userId && fav.propertyId === insertFavorite.propertyId
    );
    
    if (existing) {
      return existing;
    }
    
    const id = this.favoriteNextId++;
    const favorite: Favorite = { ...insertFavorite, id };
    this.favorites.set(id, favorite);
    return favorite;
  }
  
  async removeFavorite(userId: number, propertyId: number): Promise<boolean> {
    const favoriteToRemove = Array.from(this.favorites.values()).find(
      fav => fav.userId === userId && fav.propertyId === propertyId
    );
    
    if (favoriteToRemove) {
      return this.favorites.delete(favoriteToRemove.id);
    }
    
    return false;
  }

  // Booking operations
  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = this.bookingNextId++;
    const createdAt = new Date();
    const booking: Booking = { ...insertBooking, id, createdAt };
    this.bookings.set(id, booking);
    return booking;
  }
  
  async getUserBookings(userId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values())
      .filter(booking => booking.userId === userId);
  }

  // Category operations
  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryNextId++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  // PropertyCategory operations
  async getPropertyCategories(propertyId: number): Promise<Category[]> {
    const categoriesIds = Array.from(this.propertyCategories.values())
      .filter(pc => pc.propertyId === propertyId)
      .map(pc => pc.categoryId);
      
    return categoriesIds.map(id => 
      this.categories.get(id)
    ).filter(Boolean) as Category[];
  }
  
  // Helper function to initialize data
  private initializeData() {
    // Categories
    const categoryData: InsertCategory[] = [
      { name: "Amazing views", icon: "https://a0.muscache.com/pictures/3b1eb541-46d9-4bef-abc4-c37d77e3c21b.jpg" },
      { name: "Tiny homes", icon: "https://a0.muscache.com/pictures/c5a4f6fc-c92c-4ae8-87dd-57f1ff1b89a6.jpg" },
      { name: "Cabins", icon: "https://a0.muscache.com/pictures/732edad8-3ae0-49a8-a451-29a8010dcc0c.jpg" },
      { name: "Lakefront", icon: "https://a0.muscache.com/pictures/677a041d-7264-4c45-bb72-52bff21eb6e8.jpg" },
      { name: "Countryside", icon: "https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg" },
      { name: "Amazing pools", icon: "https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg" },
      { name: "Islands", icon: "https://a0.muscache.com/pictures/8e507f16-4943-4be9-b707-59bd38d56309.jpg" },
      { name: "Beach", icon: "https://a0.muscache.com/pictures/10ce1091-c854-40f3-a2fb-defc2995bcaf.jpg" },
      { name: "Design", icon: "https://a0.muscache.com/pictures/50861fca-582c-4bcc-89d3-857fb7ca6528.jpg" },
      { name: "Camping", icon: "https://a0.muscache.com/pictures/ca25c7f3-0d1f-432b-9efa-b9f5dc6d8770.jpg" },
      { name: "Luxe", icon: "https://a0.muscache.com/pictures/c8e2ed05-c666-47b6-99fc-4cb6edcde6b4.jpg" }
    ];
    
    categoryData.forEach(category => {
      const id = this.categoryNextId++;
      const newCategory: Category = { ...category, id };
      this.categories.set(id, newCategory);
    });
    
    // Properties
    const propertyData: InsertProperty[] = [
      {
        title: "Luxury villa with ocean view",
        description: "This stunning beachfront villa offers breathtaking ocean views and luxurious accommodations. The spacious living area opens to a private terrace overlooking the Pacific Ocean. Enjoy the infinity pool, outdoor dining area, and direct beach access. Perfect for a relaxing getaway or entertaining guests.",
        location: "Beachfront villa",
        city: "Malibu",
        state: "California",
        country: "United States",
        price: "350",
        rating: "4.97",
        reviews: 124,
        images: [
          "https://images.unsplash.com/photo-1564013799919-ab600027ffc6",
          "https://images.unsplash.com/photo-1578683010236-d716f9a3f461",
          "https://images.unsplash.com/photo-1600607688969-a5bfcd646154",
          "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea",
          "https://images.unsplash.com/photo-1560185007-c5ca9d2c0862"
        ],
        hostId: 1,
        hostName: "James",
        hostAvatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61",
        maxGuests: 6,
        bedrooms: 3,
        beds: 4,
        baths: 2,
        amenities: [
          "Beach access",
          "Infinity pool",
          "Fast WiFi",
          "65\" HDTV",
          "Gourmet kitchen",
          "Free parking",
          "Hot tub",
          "Air conditioning"
        ],
        type: "Villa",
        isSuperhost: true,
        latitude: 34.0259,
        longitude: -118.7798
      },
      {
        title: "Modern mountain retreat",
        description: "Experience the beauty of the Rockies in this modern mountain getaway. Floor-to-ceiling windows showcase stunning views of the surrounding mountains. The open-concept design includes a chef's kitchen, cozy fireplace, and luxurious bedrooms. Enjoy nearby skiing, hiking, and outdoor adventures.",
        location: "Mountain view",
        city: "Aspen",
        state: "Colorado",
        country: "United States",
        price: "425",
        rating: "4.92",
        reviews: 88,
        images: [
          "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
          "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d",
          "https://images.unsplash.com/photo-1600566752355-35792bedcfea",
          "https://images.unsplash.com/photo-1600585154526-990dced4db0d",
          "https://images.unsplash.com/photo-1600585153490-76fb20a32601"
        ],
        hostId: 2,
        hostName: "Sarah",
        hostAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
        maxGuests: 8,
        bedrooms: 4,
        beds: 5,
        baths: 3,
        amenities: [
          "Mountain views",
          "Fireplace",
          "Ski-in/ski-out",
          "Hot tub",
          "High-end kitchen",
          "Heated floors",
          "Game room",
          "Workout room"
        ],
        type: "Chalet",
        isSuperhost: true,
        latitude: 39.1911,
        longitude: -106.8175
      },
      {
        title: "Tropical beach house",
        description: "Escape to this beautiful tropical beach house with direct access to pristine white sands. The open-air design brings the outdoors in, with a spacious veranda for dining and relaxing. The property includes a private pool surrounded by lush gardens. Fall asleep to the sound of ocean waves.",
        location: "Beachfront",
        city: "Bali",
        state: "",
        country: "Indonesia",
        price: "180",
        rating: "4.89",
        reviews: 156,
        images: [
          "https://images.unsplash.com/photo-1613490493576-7fde63acd811",
          "https://images.unsplash.com/photo-1519046904884-53103b34b206",
          "https://images.unsplash.com/photo-1590523741831-ab7e8b8f9c7f",
          "https://images.unsplash.com/photo-1518684079-3c830dcef090",
          "https://images.unsplash.com/photo-1437719417032-8595fd9e9dc6"
        ],
        hostId: 3,
        hostName: "Putu",
        hostAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
        maxGuests: 4,
        bedrooms: 2,
        beds: 2,
        baths: 2,
        amenities: [
          "Beach access",
          "Private pool",
          "Air conditioning",
          "Breakfast included",
          "Outdoor shower",
          "Daily cleaning",
          "Airport transfer",
          "Bicycle rental"
        ],
        type: "Beach house",
        isSuperhost: false,
        latitude: -8.3405,
        longitude: 115.0920
      },
      {
        title: "Luxury apartment in downtown",
        description: "Experience urban luxury in this high-rise apartment with panoramic city views. The stylish interior features designer furnishings, modern artwork, and top-of-the-line appliances. Located in the heart of the city, you're steps away from world-class dining, shopping, and entertainment venues.",
        location: "City view penthouse",
        city: "New York",
        state: "New York",
        country: "United States",
        price: "295",
        rating: "4.95",
        reviews: 201,
        images: [
          "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf",
          "https://images.unsplash.com/photo-1564013799919-ab600027ffc6",
          "https://images.unsplash.com/photo-1628744448840-55bdb2497bd4",
          "https://images.unsplash.com/photo-1600607687644-a6ed62b0cdff",
          "https://images.unsplash.com/photo-1484154218962-a197022b5858"
        ],
        hostId: 4,
        hostName: "Michael",
        hostAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e",
        maxGuests: 4,
        bedrooms: 2,
        beds: 2,
        baths: 2,
        amenities: [
          "City views",
          "Doorman",
          "Gym access",
          "High-speed WiFi",
          "Smart home features",
          "Washer/dryer",
          "Coffee bar",
          "Workspace"
        ],
        type: "Apartment",
        isSuperhost: true,
        latitude: 40.7128,
        longitude: -74.0060
      },
      {
        title: "Rustic cabin in the woods",
        description: "Disconnect and recharge in this charming log cabin nestled among towering pines. The cabin features vaulted ceilings, a stone fireplace, and a wrap-around deck. Hike nearby trails, fish in the lake, or simply relax on the porch swing. The perfect blend of rustic charm and modern comforts.",
        location: "Cabin in the woods",
        city: "Lake Tahoe",
        state: "California",
        country: "United States",
        price: "215",
        rating: "4.88",
        reviews: 92,
        images: [
          "https://images.unsplash.com/photo-1566073771259-6a8506099945",
          "https://images.unsplash.com/photo-1590725175785-de025cc60835",
          "https://images.unsplash.com/photo-1636560882224-a66b23aa0dfa",
          "https://images.unsplash.com/photo-1506974210756-8e1b8985d348",
          "https://images.unsplash.com/photo-1604537529428-15bcbeecfe4d"
        ],
        hostId: 5,
        hostName: "Emma",
        hostAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
        maxGuests: 6,
        bedrooms: 3,
        beds: 4,
        baths: 2,
        amenities: [
          "Fireplace",
          "Lake view",
          "Hiking trails",
          "BBQ grill",
          "Board games",
          "Kayaks",
          "Fire pit",
          "Wildlife viewing"
        ],
        type: "Cabin",
        isSuperhost: true,
        latitude: 39.0968,
        longitude: -120.0324
      },
      {
        title: "Mediterranean villa with pool",
        description: "Enjoy the beauty of Santorini from this traditional Cycladic villa. The whitewashed walls and blue accents perfectly complement the stunning sea views. The property features a private infinity pool, multiple terraces, and an outdoor dining area. Experience the magic of Greek island living.",
        location: "Mediterranean villa",
        city: "Santorini",
        state: "",
        country: "Greece",
        price: "320",
        rating: "4.99",
        reviews: 174,
        images: [
          "https://images.unsplash.com/photo-1595521624992-9c7767578c13",
          "https://images.unsplash.com/photo-1515404929826-76fff9fef6fe",
          "https://images.unsplash.com/photo-1600210492493-0946911123ea",
          "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4",
          "https://images.unsplash.com/photo-1533104816931-20fa691ff6ca"
        ],
        hostId: 6,
        hostName: "Nikos",
        hostAvatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d",
        maxGuests: 6,
        bedrooms: 3,
        beds: 3,
        baths: 3,
        amenities: [
          "Infinity pool",
          "Sea view",
          "Air conditioning",
          "Breakfast included",
          "Daily cleaning",
          "Airport transfer",
          "Concierge service",
          "Wine tasting"
        ],
        type: "Villa",
        isSuperhost: true,
        latitude: 36.3932,
        longitude: 25.4615
      },
      {
        title: "Desert retreat with mountain views",
        description: "This stunning desert oasis offers panoramic views of the red rock mountains. The contemporary design features floor-to-ceiling windows that showcase the dramatic landscape. Relax in the private hot tub under the stars, or lounge by the pool during the day. A perfect base for exploring the natural wonders of Sedona.",
        location: "Desert retreat",
        city: "Sedona",
        state: "Arizona",
        country: "United States",
        price: "275",
        rating: "4.96",
        reviews: 133,
        images: [
          "https://images.unsplash.com/photo-1575517111839-3a3843ee7f5d",
          "https://images.unsplash.com/photo-1613977257363-707ba9348227",
          "https://images.unsplash.com/photo-1622396481328-9b1b78cdd9fd",
          "https://images.unsplash.com/photo-1489171078254-c3365d6e359f",
          "https://images.unsplash.com/photo-1513584684374-8bab748fbf90"
        ],
        hostId: 7,
        hostName: "David",
        hostAvatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5",
        maxGuests: 6,
        bedrooms: 3,
        beds: 3,
        baths: 2,
        amenities: [
          "Mountain views",
          "Private hot tub",
          "Pool",
          "Outdoor fireplace",
          "Yoga deck",
          "Telescope",
          "Hiking trails",
          "Massage available"
        ],
        type: "House",
        isSuperhost: true,
        latitude: 34.8697,
        longitude: -111.7610
      },
      {
        title: "Scandinavian modern loft",
        description: "Experience hygge in this stylish Scandinavian loft apartment. The minimalist design features natural materials, clean lines, and thoughtful details. Located in a trendy neighborhood with easy access to the city's best cafes, shops, and cultural attractions. Bicycle-friendly area with excellent public transportation.",
        location: "Scandinavian loft",
        city: "Copenhagen",
        state: "",
        country: "Denmark",
        price: "190",
        rating: "4.91",
        reviews: 85,
        images: [
          "https://images.unsplash.com/photo-1484154218962-a197022b5858",
          "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf",
          "https://images.unsplash.com/photo-1567767292278-a4f21aa2d36e",
          "https://images.unsplash.com/photo-1581428982868-3809400e2aa2",
          "https://images.unsplash.com/photo-1565183997392-2f6f122e5912"
        ],
        hostId: 8,
        hostName: "Lars",
        hostAvatar: "https://images.unsplash.com/photo-1463453091185-61582044d556",
        maxGuests: 3,
        bedrooms: 1,
        beds: 2,
        baths: 1,
        amenities: [
          "Heated floors",
          "Designer furniture",
          "High-speed WiFi",
          "Bicycle rental",
          "Rainfall shower",
          "Smart home features",
          "Coffee maker",
          "Sound system"
        ],
        type: "Apartment",
        isSuperhost: false,
        latitude: 55.6761,
        longitude: 12.5683
      }
    ];
    
    propertyData.forEach(property => {
      const id = this.propertyNextId++;
      const newProperty: Property = { ...property, id };
      this.properties.set(id, newProperty);
    });
    
    // Associate properties with categories
    const propertyCategoryAssociations = [
      { propertyId: 1, categoryId: 1 }, // Amazing views
      { propertyId: 1, categoryId: 7 }, // Beach
      { propertyId: 1, categoryId: 11 }, // Luxe
      { propertyId: 2, categoryId: 1 }, // Amazing views
      { propertyId: 2, categoryId: 3 }, // Cabins
      { propertyId: 3, categoryId: 7 }, // Beach
      { propertyId: 4, categoryId: 9 }, // Design
      { propertyId: 5, categoryId: 3 }, // Cabins
      { propertyId: 5, categoryId: 4 }, // Lakefront
      { propertyId: 6, categoryId: 1 }, // Amazing views
      { propertyId: 6, categoryId: 6 }, // Amazing pools
      { propertyId: 6, categoryId: 11 }, // Luxe
      { propertyId: 7, categoryId: 1 }, // Amazing views
      { propertyId: 7, categoryId: 9 }, // Design
      { propertyId: 8, categoryId: 9 }, // Design
    ];
    
    propertyCategoryAssociations.forEach(({ propertyId, categoryId }) => {
      const id = this.propertyCategoryNextId++;
      const newPropertyCategory: PropertyCategory = { id, propertyId, categoryId };
      this.propertyCategories.set(id, newPropertyCategory);
    });
    
    // Create a demo user
    const defaultUser: InsertUser = {
      username: "demo",
      password: "password",
      name: "Demo User",
      email: "demo@example.com",
      avatar: ""
    };
    
    const userId = this.userNextId++;
    const user: User = { ...defaultUser, id: userId };
    this.users.set(userId, user);
  }
}

// Export a singleton instance of the storage
export const storage = new MemStorage();
