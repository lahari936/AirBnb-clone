import { Link } from "wouter";
import { Globe, Facebook, Twitter, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";

const Footer = () => {
  return (
    <footer className="border-t mt-12 bg-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold mb-4">Support</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-sm hover:underline">Help Center</a></li>
              <li><a href="#" className="text-sm hover:underline">AirCover</a></li>
              <li><a href="#" className="text-sm hover:underline">Safety information</a></li>
              <li><a href="#" className="text-sm hover:underline">Supporting people with disabilities</a></li>
              <li><a href="#" className="text-sm hover:underline">Cancellation options</a></li>
              <li><a href="#" className="text-sm hover:underline">Report a neighborhood concern</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-4">Community</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-sm hover:underline">AirBnb.org: disaster relief housing</a></li>
              <li><a href="#" className="text-sm hover:underline">Combating discrimination</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-4">Hosting</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-sm hover:underline">AirBnb your home</a></li>
              <li><a href="#" className="text-sm hover:underline">AirCover for Hosts</a></li>
              <li><a href="#" className="text-sm hover:underline">Hosting resources</a></li>
              <li><a href="#" className="text-sm hover:underline">Community forum</a></li>
              <li><a href="#" className="text-sm hover:underline">Hosting responsibly</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-4">AirBnb</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-sm hover:underline">Newsroom</a></li>
              <li><a href="#" className="text-sm hover:underline">New features</a></li>
              <li><a href="#" className="text-sm hover:underline">Careers</a></li>
              <li><a href="#" className="text-sm hover:underline">Investors</a></li>
              <li><a href="#" className="text-sm hover:underline">Gift cards</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex flex-wrap gap-4 mb-4 md:mb-0">
            <span className="text-sm">© 2023 AirBnb, Inc.</span>
            <span className="text-sm">·</span>
            <a href="#" className="text-sm hover:underline">Privacy</a>
            <span className="text-sm">·</span>
            <a href="#" className="text-sm hover:underline">Terms</a>
            <span className="text-sm">·</span>
            <a href="#" className="text-sm hover:underline">Sitemap</a>
          </div>
          
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              <span>English (US)</span>
            </Button>
            <Button variant="ghost">
              <span>$ USD</span>
            </Button>
            <div className="flex gap-4 ml-4">
              <a href="#" aria-label="Facebook"><Facebook className="h-4 w-4" /></a>
              <a href="#" aria-label="Twitter"><Twitter className="h-4 w-4" /></a>
              <a href="#" aria-label="Instagram"><Instagram className="h-4 w-4" /></a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
