import { useState } from "react";
import { Property } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Calendar } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogTrigger
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { addDays, format, differenceInDays } from "date-fns";
import { Heart, Share, Star, ChevronDown, Medal, MapPin, Key } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import useFavorites from "@/hooks/useFavorites";

interface PropertyDetailProps {
  property: Property;
}

const PropertyDetail = ({ property }: PropertyDetailProps) => {
  const { toast } = useToast();
  const { isFavorite } = useFavorites(property.id);
  const [showAllPhotos, setShowAllPhotos] = useState(false);
  const [date, setDate] = useState<{
    from: Date;
    to?: Date;
  }>({
    from: new Date(),
    to: addDays(new Date(), 5),
  });
  const [guests, setGuests] = useState(2);
  const [showGuestSelector, setShowGuestSelector] = useState(false);
  
  // Calculate nights and total price
  const nights = date.to ? differenceInDays(date.to, date.from) : 0;
  const subtotal = nights * parseInt(property.price.toString());
  const cleaningFee = Math.round(parseInt(property.price.toString()) * 0.15);
  const serviceFee = Math.round(subtotal * 0.12);
  const total = subtotal + cleaningFee + serviceFee;
  
  // Toggle favorite mutation
  const addFavoriteMutation = useMutation({
    mutationFn: (propertyId: number) => {
      return apiRequest("POST", "/api/favorites", { propertyId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites/check", property.id] });
      toast({
        title: "Added to favorites",
        description: "Property has been added to your favorites list.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add to favorites.",
        variant: "destructive",
      });
    },
  });
  
  const removeFavoriteMutation = useMutation({
    mutationFn: (propertyId: number) => {
      return apiRequest("DELETE", `/api/favorites/${propertyId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites/check", property.id] });
      toast({
        title: "Removed from favorites",
        description: "Property has been removed from your favorites list.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove from favorites.",
        variant: "destructive",
      });
    },
  });
  
  const toggleFavorite = () => {
    if (isFavorite) {
      removeFavoriteMutation.mutate(property.id);
    } else {
      addFavoriteMutation.mutate(property.id);
    }
  };
  
  // Create booking mutation
  const createBookingMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/bookings", {
        propertyId: property.id,
        checkIn: format(date.from, "yyyy-MM-dd"),
        checkOut: date.to ? format(date.to, "yyyy-MM-dd") : format(addDays(date.from, 1), "yyyy-MM-dd"),
        guests,
        totalPrice: total,
      });
    },
    onSuccess: () => {
      toast({
        title: "Booking successful",
        description: "Your reservation has been confirmed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Booking failed",
        description: error.message || "Please sign in to book this property.",
        variant: "destructive",
      });
    },
  });
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Property Title */}
      <div className="mb-4">
        <h1 className="text-2xl font-bold">{property.title}</h1>
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="flex items-center">
              <Star className="h-4 w-4" />
              <span className="ml-1">{property.rating}</span>
            </span>
            <span>•</span>
            <span className="underline">{property.reviews} reviews</span>
            <span>•</span>
            <span className="underline">
              {property.city}, {property.state ? `${property.state}, ` : ''}{property.country}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="flex items-center gap-1 hover:underline">
              <Share className="h-4 w-4" />
              <span>Share</span>
            </Button>
            <Button 
              variant="ghost" 
              className="flex items-center gap-1 hover:underline"
              onClick={toggleFavorite}
            >
              <Heart className={cn("h-4 w-4", { "fill-current text-airbnb-primary": isFavorite })} />
              <span>Save</span>
            </Button>
          </div>
        </div>
      </div>
      
      {/* Property Photos */}
      <div className="relative">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mb-8">
          <div className="md:col-span-2 md:row-span-2">
            <AspectRatio ratio={1} className="h-full">
              <img src={property.images[0]} alt={property.title} className="w-full h-full object-cover rounded-lg md:rounded-l-lg md:rounded-r-none" />
            </AspectRatio>
          </div>
          <div className="hidden md:block">
            <AspectRatio ratio={1}>
              <img src={property.images[1]} alt={`${property.title} view 2`} className="w-full h-full object-cover rounded-none" />
            </AspectRatio>
          </div>
          <div className="hidden md:block">
            <AspectRatio ratio={1}>
              <img src={property.images[2]} alt={`${property.title} view 3`} className="w-full h-full object-cover rounded-tr-lg" />
            </AspectRatio>
          </div>
          <div className="hidden md:block">
            <AspectRatio ratio={1}>
              <img src={property.images[3]} alt={`${property.title} view 4`} className="w-full h-full object-cover rounded-none" />
            </AspectRatio>
          </div>
          <div className="hidden md:block">
            <AspectRatio ratio={1}>
              <img src={property.images[4]} alt={`${property.title} view 5`} className="w-full h-full object-cover rounded-br-lg" />
            </AspectRatio>
          </div>
        </div>
        
        <Dialog open={showAllPhotos} onOpenChange={setShowAllPhotos}>
          <DialogTrigger asChild>
            <Button
              variant="outline"
              className="absolute bottom-10 right-2 bg-white font-medium"
              onClick={() => setShowAllPhotos(true)}
            >
              Show all photos
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <div className="grid grid-cols-1 gap-4">
              {property.images.map((image, index) => (
                <div key={index}>
                  <AspectRatio ratio={16 / 9}>
                    <img src={image} alt={`${property.title} - Photo ${index + 1}`} className="w-full h-full object-cover rounded-lg" />
                  </AspectRatio>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Property Information */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          {/* Host Info */}
          <div className="flex justify-between items-start border-b pb-6">
            <div>
              <h2 className="text-xl font-semibold">
                {property.type} hosted by {property.hostName}
              </h2>
              <p className="text-airbnb-light">
                {property.maxGuests} guests • {property.bedrooms} bedrooms • {property.beds} beds • {property.baths} baths
              </p>
            </div>
            <img 
              src={property.hostAvatar} 
              alt={`Host ${property.hostName}`} 
              className="w-14 h-14 rounded-full"
            />
          </div>
          
          {/* Features */}
          <div className="py-6 border-b">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex gap-4">
                <Medal className="h-6 w-6 text-airbnb-dark" />
                <div>
                  <h3 className="font-semibold">Superhost</h3>
                  <p className="text-sm text-airbnb-light">Experienced, highly rated host</p>
                </div>
              </div>
              <div className="flex gap-4">
                <MapPin className="h-6 w-6 text-airbnb-dark" />
                <div>
                  <h3 className="font-semibold">Great location</h3>
                  <p className="text-sm text-airbnb-light">95% of recent guests gave the location 5 stars</p>
                </div>
              </div>
              <div className="flex gap-4">
                <Key className="h-6 w-6 text-airbnb-dark" />
                <div>
                  <h3 className="font-semibold">Self check-in</h3>
                  <p className="text-sm text-airbnb-light">Check yourself in with the keypad</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Description */}
          <div className="py-6 border-b">
            <p className="text-airbnb-dark">{property.description}</p>
            <Button variant="link" className="mt-4 font-semibold px-0">Show more</Button>
          </div>
          
          {/* Amenities */}
          <div className="py-6 border-b">
            <h2 className="text-xl font-semibold mb-4">What this place offers</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {property.amenities.slice(0, 8).map((amenity, index) => (
                <div key={index} className="flex items-center gap-4">
                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2L2 7l10 5 10-5-10-5z" />
                    <path d="M2 17l10 5 10-5" />
                    <path d="M2 12l10 5 10-5" />
                  </svg>
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
            <Button variant="outline" className="mt-6 border border-airbnb-dark rounded-lg px-6 py-2 font-semibold">
              Show all {property.amenities.length} amenities
            </Button>
          </div>
        </div>
        
        {/* Booking Widget */}
        <div className="lg:sticky lg:top-24">
          <div className="border rounded-xl shadow-lg p-6">
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className="font-semibold text-xl">${property.price}</span>
                <span className="text-airbnb-light"> night</span>
              </div>
              <div className="flex items-center">
                <Star className="h-4 w-4" />
                <span className="ml-1">{property.rating}</span>
                <span className="mx-1">•</span>
                <span className="text-airbnb-light underline">{property.reviews} reviews</span>
              </div>
            </div>
            
            {/* Date Picker */}
            <div className="border rounded-lg mb-4">
              <div className="grid grid-cols-2 border-b">
                <div className="p-3 border-r">
                  <label className="text-xs font-semibold">CHECK-IN</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="ghost" className="pl-0 w-full justify-start font-normal">
                        {date.from ? format(date.from, "PP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        initialFocus
                        mode="range"
                        defaultMonth={date.from}
                        selected={date}
                        onSelect={(range) => setDate(range as { from: Date; to?: Date })}
                        numberOfMonths={2}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="p-3">
                  <label className="text-xs font-semibold">CHECKOUT</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="ghost" className="pl-0 w-full justify-start font-normal">
                        {date.to ? format(date.to, "PP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        initialFocus
                        mode="range"
                        defaultMonth={date.from}
                        selected={date}
                        onSelect={(range) => setDate(range as { from: Date; to?: Date })}
                        numberOfMonths={2}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              <div className="p-3">
                <label className="text-xs font-semibold">GUESTS</label>
                <Popover open={showGuestSelector} onOpenChange={setShowGuestSelector}>
                  <PopoverTrigger asChild>
                    <Button variant="ghost" className="pl-0 w-full justify-between font-normal">
                      <span>{guests} {guests === 1 ? "guest" : "guests"}</span>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[250px] p-3">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Adults</p>
                          <p className="text-sm text-airbnb-light">Ages 13 or above</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-full"
                            onClick={() => setGuests(Math.max(1, guests - 1))}
                            disabled={guests <= 1}
                          >
                            -
                          </Button>
                          <span>{guests}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-full"
                            onClick={() => setGuests(Math.min(property.maxGuests, guests + 1))}
                            disabled={guests >= property.maxGuests}
                          >
                            +
                          </Button>
                        </div>
                      </div>
                      <Button 
                        variant="link" 
                        className="w-full text-right p-0"
                        onClick={() => setShowGuestSelector(false)}
                      >
                        Close
                      </Button>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            
            <Button 
              className="w-full bg-airbnb-primary text-white py-3 rounded-lg font-semibold mb-4 hover:bg-airbnb-primary/90"
              onClick={() => createBookingMutation.mutate()}
              disabled={createBookingMutation.isPending || !date.to}
            >
              {createBookingMutation.isPending ? "Processing..." : "Reserve"}
            </Button>
            
            <p className="text-center text-airbnb-light mb-6">You won't be charged yet</p>
            
            {/* Price Details */}
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="underline">${property.price} x {nights} nights</span>
                <span>${subtotal}</span>
              </div>
              <div className="flex justify-between">
                <span className="underline">Cleaning fee</span>
                <span>${cleaningFee}</span>
              </div>
              <div className="flex justify-between">
                <span className="underline">Service fee</span>
                <span>${serviceFee}</span>
              </div>
              <div className="flex justify-between pt-4 border-t font-semibold">
                <span>Total before taxes</span>
                <span>${total}</span>
              </div>
            </div>
          </div>
          
          {/* Report Listing */}
          <div className="mt-4 text-center">
            <Button variant="link" className="text-airbnb-light">Report this listing</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetail;
