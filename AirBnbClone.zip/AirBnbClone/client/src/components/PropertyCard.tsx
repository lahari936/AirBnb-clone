import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Property } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import useFavorites from "@/hooks/useFavorites";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface PropertyCardProps {
  property: Property;
  showFavoriteButton?: boolean;
}

const PropertyCard = ({ property, showFavoriteButton = true }: PropertyCardProps) => {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { isFavorite, isLoading: isCheckingFavorite } = useFavorites(property.id);
  const [isImageLoading, setIsImageLoading] = useState(true);
  const [isLoginDialogOpen, setIsLoginDialogOpen] = useState(false);
  
  // Check if user is authenticated
  const { data: user } = useQuery({
    queryKey: ["/api/auth/session"],
    retry: false,
  });
  
  // Toggle favorite mutation
  const addFavoriteMutation = useMutation({
    mutationFn: (propertyId: number) => {
      return apiRequest("POST", "/api/favorites", { propertyId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites/check", property.id] });
      toast({
        title: "Added to favorites",
        description: "Property has been added to your favorites list.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add to favorites.",
        variant: "destructive",
      });
    },
  });
  
  const removeFavoriteMutation = useMutation({
    mutationFn: (propertyId: number) => {
      return apiRequest("DELETE", `/api/favorites/${propertyId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites/check", property.id] });
      toast({
        title: "Removed from favorites",
        description: "Property has been removed from your favorites list.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove from favorites.",
        variant: "destructive",
      });
    },
  });
  
  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Check if user is authenticated 
    if (isCheckingFavorite) return;
    
    // If user is not logged in, show login dialog
    if (!user) {
      setIsLoginDialogOpen(true);
      return;
    }
    
    if (isFavorite) {
      removeFavoriteMutation.mutate(property.id);
    } else {
      addFavoriteMutation.mutate(property.id);
    }
  };
  
  const handleImageLoad = () => {
    setIsImageLoading(false);
  };

  return (
    <>
      <div className="relative rounded-xl overflow-hidden group">
        <Link href={`/property/${property.id}`}>
          <div className="relative cursor-pointer">
            {/* Favorite button */}
            {showFavoriteButton && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-3 right-3 z-10 text-white hover:bg-transparent"
                onClick={toggleFavorite}
              >
                <Heart 
                  className={cn("h-6 w-6", {
                    "fill-current text-airbnb-primary": isFavorite,
                    "stroke-current": !isFavorite
                  })} 
                />
              </Button>
            )}
            
            {/* Property image */}
            <div className="aspect-square overflow-hidden">
              {isImageLoading && (
                <div className="w-full h-full bg-gray-200 animate-pulse" />
              )}
              <img
                src={Array.isArray(property.images) && property.images.length > 0 ? property.images[0] : ''}
                alt={property.title}
                className={cn(
                  "object-cover w-full h-full transition-transform duration-300 group-hover:scale-105",
                  { "opacity-0": isImageLoading }
                )}
                onLoad={handleImageLoad}
              />
            </div>
            
            {/* Property details */}
            <div className="p-2">
              <div className="flex justify-between items-start">
                <h3 className="font-medium">{property.city}, {property.state ? `${property.state}` : property.country}</h3>
                <div className="flex items-center">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    viewBox="0 0 24 24" 
                    fill="currentColor" 
                    className="w-3 h-3"
                  >
                    <path 
                      fillRule="evenodd" 
                      d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" 
                      clipRule="evenodd" 
                    />
                  </svg>
                  <span className="ml-1 text-sm">{property.rating}</span>
                </div>
              </div>
              <p className="text-airbnb-light text-sm">{property.location}</p>
              <p className="text-airbnb-light text-sm">5 nights · Nov 12-17</p>
              <p className="mt-1"><span className="font-semibold">${property.price}</span> night</p>
            </div>
          </div>
        </Link>
      </div>

      {/* Login Dialog */}
      <Dialog open={isLoginDialogOpen} onOpenChange={setIsLoginDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Sign in to save properties</DialogTitle>
            <DialogDescription>
              You need to be signed in to save this property to your favorites.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-4">
            <p className="text-sm text-gray-600">
              Sign in to your account to save properties and access them from any device.
            </p>
            <div className="flex justify-between gap-4 mt-2">
              <Button 
                variant="outline" 
                onClick={() => setIsLoginDialogOpen(false)}
                className="w-1/2"
              >
                Cancel
              </Button>
              <Button 
                className="w-1/2 bg-airbnb-primary text-white hover:bg-airbnb-primary/90"
                onClick={() => {
                  setIsLoginDialogOpen(false);
                  // Redirect to home and open login modal
                  setLocation('/');
                  setTimeout(() => {
                    document.querySelector('[data-login-button="true"]')?.dispatchEvent(
                      new MouseEvent('click', { bubbles: true })
                    );
                  }, 100);
                }}
              >
                Sign in
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default PropertyCard;
