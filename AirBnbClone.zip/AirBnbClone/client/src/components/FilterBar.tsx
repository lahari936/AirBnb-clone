import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { 
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { SlidersHorizontal, MapPin } from "lucide-react";

const FilterBar = () => {
  const [location, setLocation] = useLocation();
  const [activeCategory, setActiveCategory] = useState<number | null>(null);
  const [showTotalBeforeTaxes, setShowTotalBeforeTaxes] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  
  // Fetch categories
  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Parse URL query params to set active filters
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const categoryParam = searchParams.get("category");
    
    if (categoryParam) {
      setActiveCategory(parseInt(categoryParam));
    } else {
      setActiveCategory(null);
    }
  }, [location]);
  
  const handleCategoryClick = (categoryId: number) => {
    if (activeCategory === categoryId) {
      // Remove filter if already active
      setActiveCategory(null);
      
      const searchParams = new URLSearchParams(window.location.search);
      searchParams.delete("category");
      
      const newQuery = searchParams.toString();
      setLocation(newQuery ? `/?${newQuery}` : "/");
    } else {
      // Apply new filter
      setActiveCategory(categoryId);
      
      const searchParams = new URLSearchParams(window.location.search);
      searchParams.set("category", categoryId.toString());
      
      const newQuery = searchParams.toString();
      setLocation(`/?${newQuery}`);
    }
  };
  
  const applyFilters = () => {
    const searchParams = new URLSearchParams(window.location.search);
    
    // Add price range to query
    searchParams.set("minPrice", priceRange[0].toString());
    searchParams.set("maxPrice", priceRange[1].toString());
    
    // Add any other filters
    
    const newQuery = searchParams.toString();
    setLocation(`/?${newQuery}`);
    setIsFiltersOpen(false);
  };
  
  return (
    <div className="border-b bg-white sticky top-16 z-40">
      <div className="container mx-auto px-4">
        {/* Categories */}
        <div className="flex items-center overflow-x-auto py-4 gap-8 whitespace-nowrap hide-scrollbar">
          {isLoading ? (
            // Loading skeleton
            Array(10).fill(0).map((_, index) => (
              <div key={index} className="flex flex-col items-center gap-1">
                <div className="w-6 h-6 bg-gray-200 rounded-full animate-pulse"></div>
                <div className="w-14 h-3 bg-gray-200 rounded animate-pulse"></div>
              </div>
            ))
          ) : (
            // Category items
            categories.map((category) => (
              <div 
                key={category.id}
                className={`flex flex-col items-center gap-1 cursor-pointer transition-opacity duration-200 ${
                  activeCategory === category.id ? "opacity-100" : "opacity-60 hover:opacity-100"
                }`}
                onClick={() => handleCategoryClick(category.id)}
              >
                <img src={category.icon} alt={category.name} className="w-6 h-6" />
                <span className="text-xs">{category.name}</span>
              </div>
            ))
          )}
        </div>
        
        {/* Filter options */}
        <div className="flex items-center justify-between py-3">
          {/* Filters Button and Modal */}
          <Sheet open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="border rounded-lg p-3 flex items-center gap-2 hover:shadow-md">
                <SlidersHorizontal className="h-4 w-4" />
                <span>Filters</span>
              </Button>
            </SheetTrigger>
            <SheetContent className="sm:max-w-md">
              <SheetHeader>
                <SheetTitle>Filters</SheetTitle>
              </SheetHeader>
              
              <div className="py-6 flex flex-col gap-6">
                {/* Price Range */}
                <div>
                  <h3 className="font-medium mb-4">Price range</h3>
                  <Slider 
                    defaultValue={priceRange} 
                    min={0} 
                    max={1000} 
                    step={10}
                    onValueChange={setPriceRange}
                    className="mb-4"
                  />
                  <div className="flex justify-between">
                    <div className="border rounded-md p-3 w-[48%]">
                      <Label htmlFor="min-price">Min Price</Label>
                      <p id="min-price" className="font-medium">${priceRange[0]}</p>
                    </div>
                    <div className="border rounded-md p-3 w-[48%]">
                      <Label htmlFor="max-price">Max Price</Label>
                      <p id="max-price" className="font-medium">${priceRange[1]}</p>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                {/* Type of place */}
                <div>
                  <h3 className="font-medium mb-4">Type of place</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="entire-home" />
                      <label htmlFor="entire-home" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Entire place
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="private-room" />
                      <label htmlFor="private-room" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Private room
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="shared-room" />
                      <label htmlFor="shared-room" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Shared room
                      </label>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                {/* Rooms and beds */}
                <div>
                  <h3 className="font-medium mb-4">Rooms and beds</h3>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm mb-2 block">Bedrooms</Label>
                      <div className="flex gap-2">
                        {["Any", "1", "2", "3", "4", "5+"].map((num) => (
                          <Button 
                            key={num} 
                            variant="outline" 
                            className="rounded-full min-w-[40px] h-[32px]"
                          >
                            {num}
                          </Button>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm mb-2 block">Beds</Label>
                      <div className="flex gap-2">
                        {["Any", "1", "2", "3", "4", "5+"].map((num) => (
                          <Button 
                            key={num} 
                            variant="outline" 
                            className="rounded-full min-w-[40px] h-[32px]"
                          >
                            {num}
                          </Button>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm mb-2 block">Bathrooms</Label>
                      <div className="flex gap-2">
                        {["Any", "1", "2", "3", "4", "5+"].map((num) => (
                          <Button 
                            key={num} 
                            variant="outline" 
                            className="rounded-full min-w-[40px] h-[32px]"
                          >
                            {num}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                {/* Amenities */}
                <div>
                  <h3 className="font-medium mb-4">Amenities</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="wifi" />
                      <label htmlFor="wifi" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        WiFi
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="kitchen" />
                      <label htmlFor="kitchen" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Kitchen
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="washer" />
                      <label htmlFor="washer" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Washer
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="dryer" />
                      <label htmlFor="dryer" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Dryer
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="ac" />
                      <label htmlFor="ac" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Air conditioning
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="heating" />
                      <label htmlFor="heating" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Heating
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="pool" />
                      <label htmlFor="pool" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Pool
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="parking" />
                      <label htmlFor="parking" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Free parking
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <Button className="w-full bg-airbnb-primary hover:bg-airbnb-primary/90" onClick={applyFilters}>
                    Show results
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
          
          <div className="flex items-center gap-3">
            {/* Display total before taxes */}
            <Button 
              variant="outline" 
              className="border rounded-lg p-3 hover:shadow-md"
              onClick={() => setShowTotalBeforeTaxes(!showTotalBeforeTaxes)}
            >
              <div className="flex items-center gap-2">
                <span className="text-sm">Display total before taxes</span>
                <Switch checked={showTotalBeforeTaxes} className="ml-1" />
              </div>
            </Button>
            
            {/* Map button */}
            <Button variant="outline" className="border rounded-lg p-3 flex items-center gap-2 hover:shadow-md">
              <span className="text-sm">Map</span>
              <MapPin className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterBar;
