import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { User } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Search } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

interface HeaderProps {
  user?: Omit<User, "password"> | null;
}

const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = loginSchema.extend({
  email: z.string().email("Please enter a valid email"),
  name: z.string().min(2, "Name must be at least 2 characters"),
});

const Header = ({ user }: HeaderProps) => {
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      email: "",
      name: "",
    },
  });
  
  // Login mutation
  const loginMutation = useMutation({
    mutationFn: (data: z.infer<typeof loginSchema>) => {
      return apiRequest("POST", "/api/auth/login", data);
    },
    onSuccess: () => {
      setIsLoginOpen(false);
      loginForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
      toast({
        title: "Login successful",
        description: "Welcome back!",
      });
    },
    onError: (error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Register mutation
  const registerMutation = useMutation({
    mutationFn: (data: z.infer<typeof registerSchema>) => {
      return apiRequest("POST", "/api/auth/register", data);
    },
    onSuccess: () => {
      setIsRegisterOpen(false);
      registerForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
      toast({
        title: "Registration successful",
        description: "Your account has been created!",
      });
    },
    onError: (error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/auth/logout", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
      setIsProfileOpen(false);
      toast({
        title: "Logged out",
        description: "You have been logged out successfully",
      });
    },
  });
  
  // Handle search submit
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };
  
  // Handle login submit
  const onLoginSubmit = (data: z.infer<typeof loginSchema>) => {
    loginMutation.mutate(data);
  };
  
  // Handle register submit
  const onRegisterSubmit = (data: z.infer<typeof registerSchema>) => {
    registerMutation.mutate(data);
  };
  
  // Close profile dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between">
        {/* Logo */}
        <Link href="/">
          <div className="flex items-center mb-4 md:mb-0 cursor-pointer">
            <svg className="w-8 h-8 text-airbnb-primary" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C14.5 2 16.5 4 16.5 6.5C16.5 9 15 11 12 14C9 11 7.5 9 7.5 6.5C7.5 4 9.5 2 12 2ZM12 0C8.5 0 5.5 2.5 5.5 6.5C5.5 10 7.5 12.5 12 17C16.5 12.5 18.5 10 18.5 6.5C18.5 2.5 15.5 0 12 0Z" />
            </svg>
            <span className="ml-2 text-xl font-bold text-airbnb-primary">AirBnb</span>
          </div>
        </Link>
        
        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} className="w-full md:w-auto mb-4 md:mb-0">
          <div className="relative rounded-full shadow-sm border border-gray-200 flex items-center">
            <Input 
              type="text" 
              placeholder="Search destinations" 
              className="w-full md:w-96 px-6 py-3 rounded-full text-sm focus:outline-none border-0 focus-visible:ring-0 shadow-none" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button type="submit" size="icon" variant="ghost" className="absolute right-0 mr-1 text-airbnb-primary">
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </form>
        
        {/* User Menu */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" className="hidden md:block text-sm font-medium hover:bg-gray-100 rounded-full">
            Become a Host
          </Button>
          
          {user ? (
            <div className="relative" ref={profileRef}>
              <button 
                className="flex items-center gap-2 border border-gray-300 rounded-full p-2 hover:shadow-md"
                onClick={() => setIsProfileOpen(!isProfileOpen)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-airbnb-dark" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <div className="w-8 h-8 bg-gray-500 rounded-full overflow-hidden flex items-center justify-center text-white">
                  {user.avatar ? (
                    <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <span>{user.name?.charAt(0)}</span>
                  )}
                </div>
              </button>
              
              {/* Dropdown Menu */}
              {isProfileOpen && (
                <div className="absolute right-0 w-64 mt-2 bg-white rounded-lg shadow-lg">
                  <ul className="py-2">
                    <li><Link href="/profile" className="block px-4 py-2 hover:bg-gray-100 text-sm">Profile</Link></li>
                    <li><Link href="/trips" className="block px-4 py-2 hover:bg-gray-100 text-sm">Trips</Link></li>
                    <li><Link href="/favorites" className="block px-4 py-2 hover:bg-gray-100 text-sm">Wishlists</Link></li>
                    <li><a href="#" className="block px-4 py-2 hover:bg-gray-100 text-sm">Settings</a></li>
                    <li>
                      <button 
                        className="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm"
                        onClick={() => logoutMutation.mutate()}
                        disabled={logoutMutation.isPending}
                      >
                        {logoutMutation.isPending ? "Logging out..." : "Log out"}
                      </button>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              {/* Login Dialog */}
              <Dialog open={isLoginOpen} onOpenChange={setIsLoginOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="rounded-full">Log in</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Login to your account</DialogTitle>
                    <DialogDescription>
                      Enter your credentials to access your account
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your username" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Enter your password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-airbnb-primary text-white hover:bg-airbnb-primary/90"
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? "Logging in..." : "Login"}
                      </Button>
                      
                      <div className="text-center mt-4">
                        <p className="text-sm text-gray-500">
                          Don't have an account?{" "}
                          <button 
                            type="button"
                            className="text-airbnb-primary hover:underline font-medium"
                            onClick={() => {
                              setIsLoginOpen(false);
                              setIsRegisterOpen(true);
                            }}
                          >
                            Register
                          </button>
                        </p>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
              
              {/* Register Dialog */}
              <Dialog open={isRegisterOpen} onOpenChange={setIsRegisterOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="rounded-full">Register</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Create an account</DialogTitle>
                    <DialogDescription>
                      Sign up to start booking your next adventure
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input placeholder="Choose a username" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Create a password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-airbnb-primary text-white hover:bg-airbnb-primary/90"
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? "Creating Account..." : "Register"}
                      </Button>
                      
                      <div className="text-center mt-4">
                        <p className="text-sm text-gray-500">
                          Already have an account?{" "}
                          <button 
                            type="button"
                            className="text-airbnb-primary hover:underline font-medium"
                            onClick={() => {
                              setIsRegisterOpen(false);
                              setIsLoginOpen(true);
                            }}
                          >
                            Login
                          </button>
                        </p>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
