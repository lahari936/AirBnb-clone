import { Switch, Route } from "wouter";
import Home from "@/pages/Home";
import PropertyPage from "@/pages/PropertyPage";
import Favorites from "@/pages/Favorites";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import NotFound from "@/pages/not-found";
import { useQuery } from "@tanstack/react-query";

function App() {
  // Check session on initial load
  const { data: user } = useQuery({
    queryKey: ["/api/auth/session"],
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: false
  });

  return (
    <div className="min-h-screen flex flex-col font-airbnb">
      <Header user={user} />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/property/:id">
            {params => <PropertyPage id={parseInt(params.id)} />}
          </Route>
          <Route path="/favorites" component={Favorites} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

export default App;
