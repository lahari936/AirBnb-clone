import { useQuery } from "@tanstack/react-query";

/**
 * Hook to check if a property is in the user's favorites
 */
const useFavorites = (propertyId: number) => {
  const { 
    data, 
    isLoading, 
    error 
  } = useQuery({
    queryKey: ["/api/favorites/check", propertyId],
    retry: false,
    // Don't show error if unauthorized - this is expected if not logged in
    queryFn: async ({ queryKey }) => {
      const res = await fetch(`${queryKey[0]}/${queryKey[1]}`, {
        credentials: "include",
      });
      
      if (res.status === 401) {
        // Return false if unauthorized instead of throwing
        return { isFavorite: false };
      }
      
      if (!res.ok) {
        throw new Error(`${res.status}: ${await res.text() || res.statusText}`);
      }
      
      return res.json();
    }
  });

  return {
    isFavorite: data?.isFavorite || false,
    isLoading,
    error
  };
};

export default useFavorites;
