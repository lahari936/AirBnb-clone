import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Property } from "@shared/schema";

/**
 * Hook to fetch and manage property listings with support for
 * search, category filtering, and pagination
 */
const useProperties = (search?: string, categoryId?: number, limit: number = 8) => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  
  // Build query string
  const buildQueryString = () => {
    const params = new URLSearchParams();
    
    if (search) {
      params.append("search", search);
    }
    
    if (categoryId) {
      params.append("category", categoryId.toString());
    }
    
    return params.toString() ? `?${params.toString()}` : "";
  };
  
  // Fetch properties
  const { 
    data, 
    isLoading, 
    error,
    refetch
  } = useQuery<Property[]>({
    queryKey: [`/api/properties${buildQueryString()}`],
  });
  
  // Reset when filters change
  useEffect(() => {
    setPage(1);
    setHasMore(true);
    
    if (data) {
      setProperties(data.slice(0, limit));
      setHasMore(data.length > limit);
    }
  }, [data, limit]);
  
  // Load more properties
  const loadMore = () => {
    if (!data || isLoading) return;
    
    const nextPage = page + 1;
    const nextBatch = data.slice(0, nextPage * limit);
    
    setProperties(nextBatch);
    setPage(nextPage);
    setHasMore(nextBatch.length < data.length);
  };
  
  // Loading more state
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  
  useEffect(() => {
    setIsLoadingMore(isLoading && page > 1);
  }, [isLoading, page]);
  
  return {
    properties,
    isLoading: isLoading && page === 1,
    isLoadingMore,
    error: error ? (error as Error).message : null,
    hasMore,
    loadMore,
    refetch
  };
};

export default useProperties;
