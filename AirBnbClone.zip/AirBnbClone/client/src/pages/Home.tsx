import { useEffect } from "react";
import FilterBar from "@/components/FilterBar";
import PropertyCard from "@/components/PropertyCard";
import { useSearch } from "wouter";
import useProperties from "@/hooks/useProperties";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

const Home = () => {
  const [searchParams] = useSearch();
  const searchQuery = new URLSearchParams(searchParams).get("search") || "";
  const categoryId = new URLSearchParams(searchParams).get("category") || "";
  
  const { 
    properties, 
    isLoading, 
    error, 
    hasMore, 
    loadMore,
    isLoadingMore
  } = useProperties(searchQuery, categoryId ? parseInt(categoryId) : undefined);

  useEffect(() => {
    document.title = searchQuery 
      ? `Search results for "${searchQuery}" | AirBnb`
      : categoryId
      ? "Category properties | AirBnb"
      : "Vacation Homes & Rentals | AirBnb";
  }, [searchQuery, categoryId]);

  return (
    <div>
      <FilterBar />
      
      <main className="container mx-auto px-4 py-8">
        {isLoading ? (
          // Loading skeleton
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array(8).fill(0).map((_, index) => (
              <div key={index} className="rounded-xl overflow-hidden">
                <Skeleton className="aspect-square" />
                <div className="p-2 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-3 w-2/3" />
                  <Skeleton className="h-4 w-1/4 mt-1" />
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          // Error state
          <div className="text-center py-12">
            <h2 className="text-xl font-bold text-red-500 mb-2">Error loading properties</h2>
            <p className="text-gray-600 mb-4">{error}</p>
            <Button 
              onClick={() => window.location.reload()}
              className="bg-airbnb-primary text-white hover:bg-airbnb-primary/90"
            >
              Try Again
            </Button>
          </div>
        ) : properties.length === 0 ? (
          // Empty state
          <div className="text-center py-12">
            <h2 className="text-xl font-bold mb-2">No properties found</h2>
            <p className="text-gray-600 mb-4">
              {searchQuery 
                ? `We couldn't find any properties matching "${searchQuery}"`
                : categoryId
                ? "No properties in this category yet"
                : "No properties available at the moment"
              }
            </p>
            <Button 
              onClick={() => window.location.href = "/"}
              className="bg-airbnb-primary text-white hover:bg-airbnb-primary/90"
            >
              Clear filters
            </Button>
          </div>
        ) : (
          // Properties grid
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {properties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
            
            {hasMore && (
              <div className="mt-8 flex justify-center">
                <Button 
                  onClick={loadMore}
                  className="bg-airbnb-primary text-white px-6 py-3 rounded-lg hover:bg-airbnb-primary/90 transition-colors duration-200"
                  disabled={isLoadingMore}
                >
                  {isLoadingMore ? "Loading more..." : "Show more properties"}
                </Button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default Home;
