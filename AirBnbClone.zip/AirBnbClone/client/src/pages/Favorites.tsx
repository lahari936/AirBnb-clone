import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import PropertyCard from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { HeartOff, Home } from "lucide-react";

const Favorites = () => {
  const [, setLocation] = useLocation();
  
  // Check if user is authenticated
  const { data: user, isLoading: isLoadingUser } = useQuery<User>({
    queryKey: ["/api/auth/session"],
    retry: false,
  });
  
  // Fetch favorites (will only work if user is authenticated)
  const { 
    data: favorites = [], 
    isLoading: isLoadingFavorites,
    error
  } = useQuery({
    queryKey: ["/api/favorites"],
    enabled: !!user,
  });
  
  useEffect(() => {
    document.title = "Saved Properties | AirBnb";
  }, []);
  
  // Loading state
  if (isLoadingUser || isLoadingFavorites) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Your Favorites</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array(4).fill(0).map((_, index) => (
            <div key={index} className="rounded-xl overflow-hidden">
              <Skeleton className="aspect-square" />
              <div className="p-2 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-3 w-2/3" />
                <Skeleton className="h-4 w-1/4 mt-1" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  // Not authenticated
  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="max-w-md mx-auto">
          <HeartOff className="h-16 w-16 mx-auto text-airbnb-primary mb-4" />
          <h1 className="text-2xl font-bold mb-4">Sign in to view your favorites</h1>
          <p className="text-gray-600 mb-6">
            You need to be signed in to save properties to your favorites list.
          </p>
          <div className="flex gap-4 justify-center">
            <Button
              onClick={() => setLocation("/")}
              variant="outline"
              className="rounded-full"
            >
              <Home className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
            <Button
              onClick={() => document.querySelector('[data-event="click:toggleUserMenu"]')?.dispatchEvent(new MouseEvent('click', { bubbles: true }))}
              className="bg-airbnb-primary text-white hover:bg-airbnb-primary/90 rounded-full"
            >
              Sign in
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  // Error state
  if (error) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
        <p className="text-gray-600 mb-6">
          We couldn't load your favorite properties. Please try again later.
        </p>
        <Button
          onClick={() => window.location.reload()}
          className="bg-airbnb-primary text-white hover:bg-airbnb-primary/90"
        >
          Try Again
        </Button>
      </div>
    );
  }
  
  // Empty favorites
  if (favorites.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="max-w-md mx-auto">
          <HeartOff className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-2xl font-bold mb-4">No favorites yet</h1>
          <p className="text-gray-600 mb-6">
            You haven't saved any properties to your favorites list yet. Browse properties and click the heart icon to add them here.
          </p>
          <Button
            onClick={() => setLocation("/")}
            className="bg-airbnb-primary text-white hover:bg-airbnb-primary/90 rounded-full"
          >
            <Home className="mr-2 h-4 w-4" />
            Browse Properties
          </Button>
        </div>
      </div>
    );
  }
  
  // Show favorites
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Your Favorites</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {favorites.map((property) => (
          <PropertyCard 
            key={property.id} 
            property={property} 
            showFavoriteButton={true}
          />
        ))}
      </div>
    </div>
  );
};

export default Favorites;
