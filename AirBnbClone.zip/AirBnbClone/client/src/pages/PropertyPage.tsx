import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import PropertyDetail from "@/components/PropertyDetail";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface PropertyPageProps {
  id: number;
}

const PropertyPage = ({ id }: PropertyPageProps) => {
  const [, setLocation] = useLocation();
  
  const { data: property, isLoading, error } = useQuery({
    queryKey: [`/api/properties/${id}`],
  });
  
  useEffect(() => {
    if (property) {
      document.title = `${property.title} | AirBnb`;
    } else {
      document.title = "Property details | AirBnb";
    }
    
    // Scroll to top when property page loads
    window.scrollTo(0, 0);
  }, [property]);
  
  const handleGoBack = () => {
    // Navigate back or to homepage
    if (window.history.length > 2) {
      window.history.back();
    } else {
      setLocation("/");
    }
  };
  
  return (
    <div className="pb-8">
      {/* Back Button */}
      <div className="container mx-auto px-4 py-6">
        <Button 
          onClick={handleGoBack} 
          variant="ghost" 
          className="flex items-center gap-2 hover:underline"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to listings</span>
        </Button>
      </div>
      
      {isLoading ? (
        <div className="container mx-auto px-4">
          {/* Loading skeleton */}
          <div className="mb-4">
            <Skeleton className="h-8 w-3/4 mb-2" />
            <div className="flex items-center gap-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mb-8">
            <div className="md:col-span-2 md:row-span-2">
              <Skeleton className="h-full aspect-square rounded-lg" />
            </div>
            <Skeleton className="h-full aspect-square rounded-none hidden md:block" />
            <Skeleton className="h-full aspect-square rounded-tr-lg hidden md:block" />
            <Skeleton className="h-full aspect-square rounded-none hidden md:block" />
            <Skeleton className="h-full aspect-square rounded-br-lg hidden md:block" />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-6">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-40 w-full" />
            </div>
            <Skeleton className="h-96 w-full rounded-xl" />
          </div>
        </div>
      ) : error ? (
        <div className="container mx-auto px-4 py-12 text-center">
          <h2 className="text-xl font-bold text-red-500 mb-4">Error loading property details</h2>
          <p className="text-gray-600 mb-6">
            We couldn't load the property you're looking for. It might have been removed or doesn't exist.
          </p>
          <Button 
            onClick={() => setLocation("/")}
            className="bg-airbnb-primary text-white hover:bg-airbnb-primary/90"
          >
            Browse other properties
          </Button>
        </div>
      ) : property ? (
        <PropertyDetail property={property} />
      ) : (
        <div className="container mx-auto px-4 py-12 text-center">
          <h2 className="text-xl font-bold mb-4">Property not found</h2>
          <p className="text-gray-600 mb-6">
            The property you're looking for doesn't exist or might have been removed.
          </p>
          <Button 
            onClick={() => setLocation("/")}
            className="bg-airbnb-primary text-white hover:bg-airbnb-primary/90"
          >
            Browse other properties
          </Button>
        </div>
      )}
    </div>
  );
};

export default PropertyPage;
